package com.example.nikolasgeorgeinventory;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.List;

/**
 * Binds inventory items to rows of the grid. The adapter only displays data and
 * reports taps; the activity decides what to save.
 */
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.RowViewHolder> {

    /** Receives the user's row actions. */
    public interface RowActionListener {
        void onQuantityChangeRequested(int position, int change);

        void onDeleteRequested(int position);
    }

    private final List<InventoryItem> items;
    private final RowActionListener listener;

    public InventoryAdapter(List<InventoryItem> items, RowActionListener listener) {
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public RowViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View row = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory_row, parent, false);
        return new RowViewHolder(row);
    }

    @Override
    public void onBindViewHolder(@NonNull RowViewHolder holder, int position) {
        InventoryItem item = items.get(position);
        View row = holder.itemView;

        holder.name.setText(item.getName());
        holder.quantity.setText(String.valueOf(item.getQuantity()));

        // Out-of-stock rows are tinted and labeled so they stand out when scanning
        boolean outOfStock = item.isOutOfStock();
        holder.outOfStockLabel.setVisibility(outOfStock ? View.VISIBLE : View.GONE);
        row.setBackgroundColor(outOfStock
                ? ContextCompat.getColor(row.getContext(), R.color.stock_out_background)
                : Color.TRANSPARENT);
        holder.decrease.setEnabled(!outOfStock);

        // Screen readers announce which item each control affects
        holder.decrease.setContentDescription(row.getContext().getString(R.string.cd_decrease, item.getName()));
        holder.increase.setContentDescription(row.getContext().getString(R.string.cd_increase, item.getName()));
        holder.delete.setContentDescription(row.getContext().getString(R.string.cd_delete, item.getName()));

        holder.decrease.setOnClickListener(v -> report(holder, -1));
        holder.increase.setOnClickListener(v -> report(holder, 1));
        holder.delete.setOnClickListener(v -> {
            int pos = holder.getBindingAdapterPosition();
            if (pos != RecyclerView.NO_POSITION) {
                listener.onDeleteRequested(pos);
            }
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    private void report(RowViewHolder holder, int change) {
        int pos = holder.getBindingAdapterPosition();
        if (pos != RecyclerView.NO_POSITION) {
            listener.onQuantityChangeRequested(pos, change);
        }
    }

    static class RowViewHolder extends RecyclerView.ViewHolder {
        final TextView name;
        final TextView outOfStockLabel;
        final TextView quantity;
        final MaterialButton decrease;
        final MaterialButton increase;
        final ImageButton delete;

        RowViewHolder(@NonNull View row) {
            super(row);
            name = row.findViewById(R.id.itemName);
            outOfStockLabel = row.findViewById(R.id.outOfStockLabel);
            quantity = row.findViewById(R.id.itemQuantity);
            decrease = row.findViewById(R.id.buttonDecrease);
            increase = row.findViewById(R.id.buttonIncrease);
            delete = row.findViewById(R.id.buttonDelete);
        }
    }
}
