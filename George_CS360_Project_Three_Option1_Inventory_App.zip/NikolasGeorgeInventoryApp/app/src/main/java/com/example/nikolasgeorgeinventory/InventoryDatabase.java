package com.example.nikolasgeorgeinventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Owns the app's SQLite database. Every read and write for users and inventory
 * items goes through this class, so no activity touches SQL directly.
 */
public class InventoryDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 1;

    // Users table: login credentials. Passwords are stored only as salted hashes.
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "_id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD_HASH = "password_hash";
    private static final String COL_SALT = "salt";

    // Items table: one row per inventory item
    private static final String TABLE_ITEMS = "items";
    private static final String COL_ITEM_ID = "_id";
    private static final String COL_ITEM_NAME = "name";
    private static final String COL_QUANTITY = "quantity";

    private static InventoryDatabase instance;

    /** Returns the single shared database helper for the whole app. */
    public static synchronized InventoryDatabase getInstance(Context context) {
        if (instance == null) {
            instance = new InventoryDatabase(context.getApplicationContext());
        }
        return instance;
    }

    private InventoryDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + " ("
                + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USERNAME + " TEXT NOT NULL UNIQUE COLLATE NOCASE, "
                + COL_PASSWORD_HASH + " TEXT NOT NULL, "
                + COL_SALT + " TEXT NOT NULL)");

        db.execSQL("CREATE TABLE " + TABLE_ITEMS + " ("
                + COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_ITEM_NAME + " TEXT NOT NULL, "
                + COL_QUANTITY + " INTEGER NOT NULL DEFAULT 0 CHECK (" + COL_QUANTITY + " >= 0))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Version 1 is the only schema so far; future versions migrate here
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);
        onCreate(db);
    }

    // ---------------------------------------------------------------- users

    /** True if an account with this username already exists (case-insensitive). */
    public boolean userExists(String username) {
        try (Cursor cursor = getReadableDatabase().query(TABLE_USERS, new String[]{COL_USER_ID},
                COL_USERNAME + " = ?", new String[]{username}, null, null, null)) {
            return cursor.moveToFirst();
        }
    }

    /**
     * Creates a new account. Returns false if the username is already taken.
     */
    public boolean addUser(String username, String password) {
        if (userExists(username)) {
            return false;
        }
        String salt = PasswordHasher.newSalt();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_SALT, salt);
        values.put(COL_PASSWORD_HASH, PasswordHasher.hash(password, salt));
        return getWritableDatabase().insert(TABLE_USERS, null, values) != -1;
    }

    /** True if the username exists and the password matches its stored hash. */
    public boolean validateUser(String username, String password) {
        try (Cursor cursor = getReadableDatabase().query(TABLE_USERS,
                new String[]{COL_PASSWORD_HASH, COL_SALT},
                COL_USERNAME + " = ?", new String[]{username}, null, null, null)) {
            if (!cursor.moveToFirst()) {
                return false;
            }
            String storedHash = cursor.getString(0);
            String salt = cursor.getString(1);
            return PasswordHasher.matches(password, salt, storedHash);
        }
    }

    // ---------------------------------------------------------------- items

    /** Read: every item, alphabetized for easy scanning. */
    public List<InventoryItem> getAllItems() {
        List<InventoryItem> items = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query(TABLE_ITEMS,
                new String[]{COL_ITEM_ID, COL_ITEM_NAME, COL_QUANTITY},
                null, null, null, null, COL_ITEM_NAME + " COLLATE NOCASE")) {
            while (cursor.moveToNext()) {
                items.add(new InventoryItem(cursor.getLong(0), cursor.getString(1), cursor.getInt(2)));
            }
        }
        return items;
    }

    /** Create: adds an item and returns its new row ID, or -1 on failure. */
    public long addItem(String name, int quantity) {
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_QUANTITY, Math.max(0, quantity));
        return getWritableDatabase().insert(TABLE_ITEMS, null, values);
    }

    /** Update: sets a new quantity for one item. */
    public boolean updateQuantity(long itemId, int quantity) {
        ContentValues values = new ContentValues();
        values.put(COL_QUANTITY, Math.max(0, quantity));
        return getWritableDatabase().update(TABLE_ITEMS, values,
                COL_ITEM_ID + " = ?", new String[]{String.valueOf(itemId)}) == 1;
    }

    /** Delete: removes one item. */
    public boolean deleteItem(long itemId) {
        return getWritableDatabase().delete(TABLE_ITEMS,
                COL_ITEM_ID + " = ?", new String[]{String.valueOf(itemId)}) == 1;
    }
}
