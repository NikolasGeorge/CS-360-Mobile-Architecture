package com.example.nikolasgeorgeinventory;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

/**
 * Form for adding a new inventory item to the database.
 */
public class AddItemActivity extends AppCompatActivity {

    private TextInputLayout nameLayout;
    private TextInputLayout quantityLayout;
    private TextInputEditText nameText;
    private TextInputEditText quantityText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        nameLayout = findViewById(R.id.itemNameLayout);
        quantityLayout = findViewById(R.id.itemQuantityLayout);
        nameText = findViewById(R.id.itemNameText);
        quantityText = findViewById(R.id.itemQuantityText);

        findViewById(R.id.buttonCancel).setOnClickListener(v -> finish());
        findViewById(R.id.buttonSave).setOnClickListener(v -> saveItem());
    }

    private void saveItem() {
        String name = nameText.getText() == null ? "" : nameText.getText().toString().trim();
        String quantityInput = quantityText.getText() == null ? "" : quantityText.getText().toString().trim();

        // Validate both fields before touching the database
        nameLayout.setError(TextUtils.isEmpty(name) ? getString(R.string.error_item_name) : null);
        Integer quantity = parseQuantity(quantityInput);
        quantityLayout.setError(quantity == null ? getString(R.string.error_quantity) : null);
        if (TextUtils.isEmpty(name) || quantity == null) {
            return;
        }

        if (InventoryDatabase.getInstance(this).addItem(name, quantity) == -1) {
            Toast.makeText(this, R.string.error_save_failed, Toast.LENGTH_SHORT).show();
            return;
        }
        // The grid reloads in onResume, so the new item appears when we return
        finish();
    }

    /** Returns a whole number of 0 or more, or null if the input is not one. */
    private Integer parseQuantity(String input) {
        if (TextUtils.isEmpty(input)) {
            return null;
        }
        try {
            int value = Integer.parseInt(input);
            return value >= 0 ? value : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
