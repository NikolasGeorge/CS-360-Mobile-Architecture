package com.example.nikolasgeorgeinventory;

/**
 * A single stock item, matching one row of the items table.
 */
public class InventoryItem {

    private final long id;
    private final String name;
    private int quantity;

    public InventoryItem(long id, String name, int quantity) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        // Stock can never go below zero
        this.quantity = Math.max(0, quantity);
    }

    public boolean isOutOfStock() {
        return quantity == 0;
    }
}
