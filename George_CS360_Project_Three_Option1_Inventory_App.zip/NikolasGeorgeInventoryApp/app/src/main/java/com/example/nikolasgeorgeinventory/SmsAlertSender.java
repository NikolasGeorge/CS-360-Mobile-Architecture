package com.example.nikolasgeorgeinventory;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.util.Log;

import androidx.core.content.ContextCompat;

/**
 * Sends the out-of-stock text alert. Every send is checked first, so a user
 * who denied permission or never entered a phone number simply gets no text,
 * and the rest of the app keeps working.
 */
public final class SmsAlertSender {

    private static final String TAG = "SmsAlertSender";
    private static final String PREFS = "alert_settings";
    private static final String KEY_PHONE = "alert_phone";

    private SmsAlertSender() {
        // Utility class; not meant to be instantiated
    }

    /** Saves the number that should receive alerts. */
    public static void savePhoneNumber(Context context, String phoneNumber) {
        prefs(context).edit().putString(KEY_PHONE, phoneNumber).apply();
    }

    /** Returns the saved alert number, or an empty string if none is set. */
    public static String getPhoneNumber(Context context) {
        return prefs(context).getString(KEY_PHONE, "");
    }

    /** True if the user granted SMS permission. */
    public static boolean hasPermission(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    /** True only when every condition for sending is met. */
    public static boolean canSend(Context context) {
        return hasPermission(context)
                && !TextUtils.isEmpty(getPhoneNumber(context))
                && context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_TELEPHONY_MESSAGING);
    }

    /**
     * Texts the user that an item has run out.
     *
     * @return true if the message was handed to the system for delivery
     */
    public static boolean sendOutOfStockAlert(Context context, String itemName) {
        if (!canSend(context)) {
            return false;
        }
        try {
            SmsManager smsManager = context.getSystemService(SmsManager.class);
            String message = context.getString(R.string.sms_message, itemName);
            smsManager.sendTextMessage(getPhoneNumber(context), null, message, null, null);
            return true;
        } catch (RuntimeException e) {
            // A failed text should never crash inventory work
            Log.w(TAG, "Could not send out-of-stock alert", e);
            return false;
        }
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
