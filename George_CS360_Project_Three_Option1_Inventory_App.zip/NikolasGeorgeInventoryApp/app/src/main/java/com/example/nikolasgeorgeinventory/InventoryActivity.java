package com.example.nikolasgeorgeinventory;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * Home screen: the inventory grid. Reads items from the database, saves every
 * change the user makes, and triggers the out-of-stock alert.
 */
public class InventoryActivity extends AppCompatActivity implements InventoryAdapter.RowActionListener {

    private final List<InventoryItem> items = new ArrayList<>();
    private InventoryDatabase database;
    private InventoryAdapter adapter;
    private TextView emptyInventory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        database = InventoryDatabase.getInstance(this);
        emptyInventory = findViewById(R.id.emptyInventory);

        RecyclerView grid = findViewById(R.id.inventoryGrid);
        grid.setLayoutManager(new LinearLayoutManager(this));
        grid.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        adapter = new InventoryAdapter(items, this);
        grid.setAdapter(adapter);

        findViewById(R.id.buttonAddItem).setOnClickListener(
                v -> startActivity(new Intent(this, AddItemActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Reload every time the grid returns to the foreground, so items added
        // on the Add Item screen appear immediately
        refreshItems();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_inventory, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.action_alerts) {
            startActivity(new Intent(this, SmsNotificationActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onQuantityChangeRequested(int position, int change) {
        InventoryItem item = items.get(position);
        int oldQuantity = item.getQuantity();
        int newQuantity = Math.max(0, oldQuantity + change);

        if (!database.updateQuantity(item.getId(), newQuantity)) {
            Toast.makeText(this, R.string.error_save_failed, Toast.LENGTH_SHORT).show();
            return;
        }
        item.setQuantity(newQuantity);
        adapter.notifyItemChanged(position);

        // Alert only on the change that empties the shelf, not on every tap at zero
        if (oldQuantity > 0 && newQuantity == 0) {
            notifyOutOfStock(item);
        }
    }

    @Override
    public void onDeleteRequested(int position) {
        InventoryItem item = items.get(position);
        // Deleting cannot be undone, so confirm first
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_title)
                .setMessage(getString(R.string.delete_message, item.getName()))
                .setNegativeButton(R.string.button_cancel, null)
                .setPositiveButton(R.string.button_delete, (dialog, which) -> deleteItem(item))
                .show();
    }

    private void deleteItem(InventoryItem item) {
        int position = items.indexOf(item);
        if (position < 0 || !database.deleteItem(item.getId())) {
            Toast.makeText(this, R.string.error_save_failed, Toast.LENGTH_SHORT).show();
            return;
        }
        items.remove(position);
        adapter.notifyItemRemoved(position);
        updateEmptyState();
    }

    private void notifyOutOfStock(InventoryItem item) {
        // If SMS is unavailable or denied, the highlighted row is the alert
        if (SmsAlertSender.sendOutOfStockAlert(this, item.getName())) {
            Toast.makeText(this, getString(R.string.alert_sent, item.getName()), Toast.LENGTH_LONG).show();
        }
    }

    @SuppressWarnings("NotifyDataSetChanged") // The whole list is replaced from the database
    private void refreshItems() {
        items.clear();
        items.addAll(database.getAllItems());
        adapter.notifyDataSetChanged();
        updateEmptyState();
    }

    private void updateEmptyState() {
        emptyInventory.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
    }
}
