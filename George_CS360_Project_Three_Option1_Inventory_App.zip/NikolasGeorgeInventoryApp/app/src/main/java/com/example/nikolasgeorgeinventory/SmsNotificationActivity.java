package com.example.nikolasgeorgeinventory;

import android.Manifest;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

/**
 * Explains the out-of-stock text alert, saves the number to text, asks for SMS
 * permission, and shows the result. Denying permission never blocks the app.
 */
public class SmsNotificationActivity extends AppCompatActivity {

    private TextView smsStatus;
    private TextInputLayout phoneLayout;
    private TextInputEditText phoneText;

    // Receives the user's answer to the system permission dialog
    private final ActivityResultLauncher<String> requestSmsPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(),
                    granted -> showStatus(granted));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notification);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        smsStatus = findViewById(R.id.smsStatus);
        phoneLayout = findViewById(R.id.phoneLayout);
        phoneText = findViewById(R.id.phoneText);

        // Show what the user chose on a previous visit
        phoneText.setText(SmsAlertSender.getPhoneNumber(this));
        if (SmsAlertSender.hasPermission(this) && !TextUtils.isEmpty(SmsAlertSender.getPhoneNumber(this))) {
            showStatus(true);
        }

        findViewById(R.id.buttonEnableAlerts).setOnClickListener(v -> enableAlerts());
        findViewById(R.id.buttonNotNow).setOnClickListener(v -> finish());
    }

    private void enableAlerts() {
        String phone = phoneText.getText() == null ? "" : phoneText.getText().toString().trim();
        if (TextUtils.isEmpty(phone)) {
            phoneLayout.setError(getString(R.string.error_phone));
            return;
        }
        phoneLayout.setError(null);
        SmsAlertSender.savePhoneNumber(this, phone);

        // Always check before sending; only ask if permission is missing
        if (SmsAlertSender.hasPermission(this)) {
            showStatus(true);
        } else {
            requestSmsPermission.launch(Manifest.permission.SEND_SMS);
        }
    }

    private void showStatus(boolean granted) {
        smsStatus.setText(granted ? R.string.sms_status_granted : R.string.sms_status_denied);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
