package com.example.nikolasgeorgeinventory;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Login screen. Log In checks the credentials against the users table; Create
 * Account saves a new user from the same two fields.
 */
public class LoginActivity extends AppCompatActivity {

    private InventoryDatabase database;
    private TextInputEditText usernameText;
    private TextInputEditText passwordText;
    private TextView loginError;
    private View buttonLogIn;
    private View buttonCreateAccount;

    // Password hashing is deliberately slow, so it runs off the main thread
    private final ExecutorService background = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // The screen shows its own large title, so the app bar would just repeat it
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        database = InventoryDatabase.getInstance(this);
        usernameText = findViewById(R.id.usernameText);
        passwordText = findViewById(R.id.passwordText);
        loginError = findViewById(R.id.loginError);
        buttonLogIn = findViewById(R.id.buttonLogIn);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        buttonLogIn.setOnClickListener(v -> logIn());
        buttonCreateAccount.setOnClickListener(v -> createAccount());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        background.shutdown();
    }

    private void logIn() {
        String username = readUsername();
        String password = readPassword();
        if (!hasBothFields(username, password)) {
            return;
        }
        runCheck(() -> database.validateUser(username, password), R.string.error_login_failed);
    }

    private void createAccount() {
        String username = readUsername();
        String password = readPassword();
        if (!hasBothFields(username, password)) {
            return;
        }
        runCheck(() -> database.addUser(username, password), R.string.error_username_taken);
    }

    /** A credential check that returns true when the user may continue. */
    private interface CredentialCheck {
        boolean run();
    }

    /**
     * Runs a database check in the background, then either opens the grid or
     * shows the given error.
     */
    private void runCheck(CredentialCheck check, @StringRes int errorMessage) {
        setButtonsEnabled(false);
        background.execute(() -> {
            boolean success = check.run();
            runOnUiThread(() -> {
                setButtonsEnabled(true);
                if (success) {
                    openInventory();
                } else {
                    showError(errorMessage);
                }
            });
        });
    }

    private boolean hasBothFields(String username, String password) {
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            showError(R.string.error_missing_credentials);
            return false;
        }
        return true;
    }

    private void openInventory() {
        startActivity(new Intent(this, InventoryActivity.class));
        // Close the login screen so Back from the grid exits the app
        finish();
    }

    private void showError(@StringRes int message) {
        loginError.setText(message);
        loginError.setVisibility(View.VISIBLE);
    }

    private void setButtonsEnabled(boolean enabled) {
        buttonLogIn.setEnabled(enabled);
        buttonCreateAccount.setEnabled(enabled);
    }

    private String readUsername() {
        return usernameText.getText() == null ? "" : usernameText.getText().toString().trim();
    }

    private String readPassword() {
        return passwordText.getText() == null ? "" : passwordText.getText().toString();
    }
}
